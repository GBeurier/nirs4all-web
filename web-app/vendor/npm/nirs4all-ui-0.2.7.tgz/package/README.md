# nirs4all-ui

Shared React UI components, visual assets, default styles, brand generators,
and pure TypeScript view-model helpers used by nirs4all Studio, the standalone
web/WASM client, and custom NIRS4ALL app hosts.

This package intentionally keeps components presentational and keeps the
framework-free helpers free of hooks, API clients, filesystem access, browser
globals, or backend/runtime execution. Hosts own app state, routing, data
fetching, and icons; this package owns shared display contracts and reusable
UI surfaces. It also ships the reusable graphical system for the ecosystem:
brand manifests, generated SVG marks, default CSS tokens, and the shared NIR
spectra motion asset.

## Domains

| Domain | Export | What it owns |
| --- | --- | --- |
| `score` | `nirs4all-ui/score` | Metric-key normalization, metric catalog helpers, direction-aware score parsing, comparison, and formatting. |
| `runtime` | `nirs4all-ui/runtime` | Runtime/result status display tokens, busy-state predicates, progress projection, engine metadata summaries, diagnostics, and native-result affordances. |
| `ranking` | `nirs4all-ui/ranking` | Presentational native ranking, paired relative-gain, adjusted mixed-effects and surrogate fANOVA views. Hosts supply versioned artifacts and optional Plotly rendering; exact values, declared references/domains and diagnostics remain available in HTML tables. No model fitting or importance computation runs in these views. |
| `multimodal` | `nirs4all-ui/multimodal` | Controlled multisource / multimodal fusion teaching workbench: case selector, per-source spectra on their own axes, genetic dosage table, image gallery with linked sample selection, identity-matching report, per-source preprocessing editor, strategy explanations with a branch-and-merge recipe view (reusing `dag`), shared validation protocol, run/cancel/progress, and owner-scored OOF/held-out comparison (reusing `viz`). Hosts own loading, IO, worker execution and downloads; styles at `nirs4all-ui/assets/multimodal.css`. |
| `pipelineEditor` | `nirs4all-ui/pipelineEditor` | `PipelineChainEditor`: a rack-style editor for canonical nirs4all pipelines. Steps are cells on a left-to-right signal wire, branches and alternatives are parallel lanes that split and join, generators and finetuning read on the cells, and a device strip edits the selected step. Controlled (document in, document out) over a host-supplied operator catalogue; edits are applied to the pipeline JSON in place so unmodelled constructs survive. Pure view model exported (`parsePipeline`, `layoutChain`, edit operations); styles at `nirs4all-ui/assets/pipelineEditor.css`. Trial status: not yet adopted by a host. |
| `conformal` | `nirs4all-ui/conformal` | Validation and pure view-model projection for native nirs4all `CalibratedRunResult.to_dict()` and `ConformalMetricSet.to_dict()` payloads, guarantee-status badges, calibration replay provenance, coverage options, per-sample prediction interval rows, materialized interval summaries, and empirical metric rows. |
| `robustness` | `nirs4all-ui/robustness` | Validation and compact card view-models for nirs4all robustness `summary.json` artifacts, optional conformal guarantee badge projection, plus fallback and registry-derived mode/scenario/distribution vocabulary and form validation aligned with the Python keyword registry. |
| `keywordRegistry` | `nirs4all-ui/keywordRegistry` | Metadata-only validation, indexing, id/path/token/alias resolution, value-option extraction, form-field projection, ordered form-section grouping, optimizer-persistence field grouping, and workspace prediction publication contract projection for the exported full Python nirs4all keyword/effect registry. |
| `nodeRegistry` | `nirs4all-ui/nodeRegistry` | `projectN4mManifest`: projects the n4m method manifest (`n4m_cli --manifest-json`) into typed pipeline-editor node definitions — role → node type, typed parameters (bounds, choices, unset defaults), required fit inputs, `n4m:<method_id>` operator token. |
| `tuning` | `nirs4all-ui/tuning` | Validation and pure view-model projection for native nirs4all `TuningResult.to_dict()` payloads, lightweight `TuningResult.summary_artifact()` / `nirs4all.tuning.summary` cards, and pre-execution `nirs4all.tuning.ordered_search_space` artifacts for Studio/Web forms without optimizer logic. |
| `dataset` | `nirs4all-ui/dataset` | Dataset preview contracts, counts, split summaries, spectral ranges, task labels, badges, and stats. |
| `components` | `nirs4all-ui/components` | Stateless React components that render shared runtime, diagnostic, and metric affordances. |
| `viz` | `nirs4all-ui/viz` | Dependency-free scientific SVG charts. Each chart provides a data-derived accessible description and accepts a `description` override for localized or domain-specific wording. Hosts supply computed values and retain analysis/execution. `SpectralImportanceChart` accepts optional `bands`/`bandsLabel` to overlay reference absorption bands; `bandFocus="important"` (default `"all"`) keeps only the bands overlapping regions whose strength (\|value\| / strongest \|value\|) is at least `bandImportanceThreshold` (default 0.5), labels them with their short assignment and lists each important region's candidate bands in the summary and band table (`importantBandsLabel` captions them; overlap is a candidate assignment, not evidence of chemical causation; the pure `bandsForImportantRegions` helper is exported); `referenceBandsForAxis(unit, min, max)` maps the static, literature-cited `NIR_REFERENCE_BANDS` catalog (approximate, matrix-dependent windows) to nm, µm or cm⁻¹ axes and returns no bands for feature indices or unknown units. |
| `dag` | `nirs4all-ui/dag` | Interactive compiled-DAG explorer (layered layout, pan/zoom, culling/LOD, collapsible clusters) plus the pure engine and a `fromCompiledGraph` adapter for a serialized DAG-ML graph/plan. |
| `chains` | `nirs4all-ui/chains` | Chain-effect explorer over a corpus of scored pipelines: per-node influence ranking, position (early/mid/late) and predecessor×successor order effects, and with/without distribution shift, with per-dataset rank/z normalization. Pure engine + charts + interactive explorer, plus a `parseChainEffectAnalysis` adapter for the serialized `dag-ml` artifact. |
| `workbench` | `nirs4all-ui/workbench` | Shared interactive-analysis kit behind the capsules: selection algebra (click / box / lasso, Shift add · Alt subtract · Ctrl toggle), color-by resolution, canvas views (`SpectraView` lines / bands / density, `ScatterView`, `DistributionView`, `ProfileView`) on a layered `CanvasPlot`, view grid with layout presets, panel chrome, virtual table, capsule-scoped shortcuts. |
| `playground` | `nirs4all-ui/playground` | The **Playground capsule**: dataset exploration and live operator chains (pipeline timeline with preview cursor, operator picker, linked spectra / scores / target / T²–Q / loadings / r(λ) / folds / replicates / samples views, selection drawer). The host executes `PlaygroundRunRequest`s and returns `PlaygroundResult`s. |
| `inspector` | `nirs4all-ui/inspector` | The **Inspector capsule**: rank and dissect trained chains (leaderboard with ☆ compare, score landscape, pivot heatmap, generalization, hyper-parameters, step effects, parity, residuals, fold stability, confusion, hard samples, chain details with step diff). The host supplies chains, score references and on-demand predictions. |
| `lab` | `nirs4all-ui/lab` | Quality/lab decision, sample lifecycle, health, model report, worklist, and budget display contracts plus presentational components. |
| `datasetBuilder` | `nirs4all-ui/datasetBuilder` | Multisource dataset-builder wizard components and pure dataset-config helpers. |
| `brand` | `nirs4all-ui/brand` | Ecosystem brand definitions, stable asset paths, palettes, and deterministic SVG generators. |
| `styles` | `nirs4all-ui/styles` | Default theme tokens, CSS/motion asset manifests, and CSS variable helpers. |
| `browser` | `nirs4all-ui/browser` | Optional self-contained entry for vanilla (non-React) hosts: three mount functions for the dataset preview card, the spectra explorer (whose own accessible band-data table is the only data table), and the controlled owner proposal list. Bundles React; never part of the root barrel. |
| `assets` | `nirs4all-ui/assets/*` | Package logo kit, ecosystem brand SVGs, default CSS, dataset-builder CSS, quality/lab theme CSS, and animated NIR spectra asset. |

The root export also exposes namespace barrels:

```ts
import { brand, chains, conformal, dag, inspector, playground, workbench, dataset, datasetBuilder, keywordRegistry, lab, nodeRegistry, robustness, runtime, score, styles, tuning } from "nirs4all-ui";
```

Prefer domain imports when a consumer only needs one area:

```ts
import { canonicalMetricKey, formatMetricValue } from "nirs4all-ui/score";
import { buildDatasetPreview } from "nirs4all-ui/dataset";
import { buildRuntimeResultStatusView } from "nirs4all-ui/runtime";
import { createConformalGuaranteeView, getCalibrationReplaySource, parseCalibratedRunResultArtifact } from "nirs4all-ui/conformal";
import { createRobustnessGuaranteeView, createRobustnessSummaryCards, getRobustnessSpectralReplay, parseRobustnessSummaryArtifact, validateRobustnessScenarioDraft } from "nirs4all-ui/robustness";
import { createKeywordRegistryFieldViews, createKeywordRegistryWorkspacePredictionPublicationContract, parseKeywordRegistryDocument } from "nirs4all-ui/keywordRegistry";
import { projectN4mManifest } from "nirs4all-ui/nodeRegistry";
import { createTuningSearchSpacePreview, createTuningStudySummary, createTuningSummaryCard, createTuningTrialRows, parseOrderedTuningSearchSpaceArtifact, parseTuningResultArtifact, parseTuningSummaryArtifact } from "nirs4all-ui/tuning";
import { DatasetBuilder, MultimodalDatasetBuilder } from "nirs4all-ui/datasetBuilder";
import { Playground } from "nirs4all-ui/playground";
import { Inspector } from "nirs4all-ui/inspector";
import { SpectraView, ScatterView, combineSelection } from "nirs4all-ui/workbench";
import { DagGraphView, fromCompiledGraph } from "nirs4all-ui/dag";
import { ChainExplorer, fromScoredChains, parseChainEffectAnalysis } from "nirs4all-ui/chains";
import { DecisionBadge } from "nirs4all-ui/lab";
import { generateNirs4allBrandSvg } from "nirs4all-ui/brand";
import { getNirs4allStyleAsset } from "nirs4all-ui/styles";
import { MetricValueBadge, RuntimeEngineBadge } from "nirs4all-ui/components";
```

`MultimodalDatasetBuilder` is the controlled four-stage Source → Role → Columns →
Validation importer. Pass host-inspected `files` and `draft`, handle
`onAddFiles` / `onRemoveFile` / `onDraftChange`, and return owner inspection
through `validation` after `onValidate`. Reset validation on every draft or file
edit. `onCreate` is enabled only for a current successful validation; hosts also
guard the exact accepted revision. The component performs no file reads, parsing,
identity joins or execution. Its `MultimodalDatasetBuilderProps` and source DTOs
are exported from the same entrypoint. The showroom includes an explicitly
illustrative controlled host; the Web multimodal laboratory uses actual
IO/Formats inspection and materialization. `MultimodalWorkbench.datasetBuilder`
accepts the hosted component while keeping example downloads available.

`MultimodalPipelineEditor` from `nirs4all-ui/multimodal` is a controlled editor for
source branches, per-source preprocessing, PLS/Ridge/MB-PLS/neural models, and a
fixed prediction mean or learned PLS/Ridge meta-model. Import
`nirs4all-ui/assets/multimodal.css` alongside the component:

```tsx
import { useState } from "react";
import { MultimodalPipelineEditor, type MultimodalPipelineDocument } from "nirs4all-ui/multimodal";

const [pipeline, setPipeline] = useState<MultimodalPipelineDocument>(presets[0]!.document);

<MultimodalPipelineEditor
  sources={sources}
  value={pipeline}
  onChange={setPipeline}
  presets={presets}
  onLoadPreset={(id) => setPipeline(structuredClone(presets.find((p) => p.id === id)!.document))}
/>
```

Supply source descriptors and editable preset documents from the host. Loading a
preset replaces the document; subsequent edits remain in that document. The
component shows structural issues and preserves branches and raw inputs across
merge changes. No merge requires one branch; mean or learned merging requires at
least two. Raw merge inputs make a learned merge hybrid. Hosts own file reads,
IO, import validation, native DSL adaptation, fold/group/OOF safeguards, worker
execution, persistence and results. This is a branch-and-optional-merge document,
not an arbitrary native DAG editor. The showroom's full-width example edits real
local state with metadata-only sources and no simulated execution. For actual
training, open the [WASM multimodal laboratory](https://web.nirs4all.org/nirs4all_multimodale/).

### Pipeline chain editor (trial)

`PipelineChainEditor` from `nirs4all-ui/pipelineEditor` edits a nirs4all pipeline
laid out as a signal chain. It is new and not wired into Studio or Web yet. Try it
with the standalone page:

```bash
npm run demo:pipeline-editor   # then open http://localhost:5173/nirs4all-ui/pipeline-editor/
```

The page is served by the showroom dev server only; it is not part of
`npm run site:build`. It loads a mock catalogue and a few pipelines (two of them
Studio presets).

```tsx
import { useState } from "react";
import { PipelineChainEditor, fromCanonicalPipeline, toCanonicalPipeline, type PipelineChainDocument } from "nirs4all-ui/pipelineEditor";
import "nirs4all-ui/assets/pipelineEditor.css";

const [pipeline, setPipeline] = useState<PipelineChainDocument>(() => fromCanonicalPipeline(loaded));

<PipelineChainEditor value={pipeline} onChange={setPipeline} catalog={{ operators }} onUndo={undo} onRedo={redo} />;

run(toCanonicalPipeline(pipeline));
```

- **Document.** The value is the canonical pipeline wrapper (`{ name, description,
  pipeline }`, the list of steps the SDK loads). The editor never converts it to a
  private format: each cell points at a JSON path and edits rewrite only that
  place. Steps it does not model (separation branches, `sample_augmentation`,
  `source_branch`, unknown keys, ...) are shown as raw cells, can be moved,
  bypassed and edited as JSON, and are otherwise left exactly as they were.
- **Catalogue.** `catalog.operators` lists what can be inserted and describes the
  parameters (`PipelineOperatorDefinition`; `nodeRegistry.NodeDefinition` and
  Studio registry entries fit it structurally). No operator is built in. An
  operator absent from the catalogue still renders and its parameters stay
  editable. Inserted steps carry no explicit parameters, so runtime defaults apply
  until a value is set.
- **Layout.** Left-to-right wire between the dataset and results terminals, on a
  24 px grid. A `branch` draws solid fans to full-height lanes; a `source_branch`
  or a `branch` with `by_source: true` and named `steps` draws one lane per data
  source (lanes are the dataset's sources, so none is added from the editor), and
  `merge_sources` reads as a source merge; `_or_`
  alternatives draw a compact bank on dotted wires (one option per variant);
  `_cartesian_` stages sit in a dashed frame; `concat_transform` and
  `feature_augmentation` lists are banks on solid buses. The top-level chain wraps
  onto rows (toggle for a single scrolling row) and zooms.
- **Generators and tuning.** A parameter is fixed, swept (`_or_`, `_range_`,
  `_log_range_`, written under `params`; an existing `_range_` + `param` on a
  model step is edited where it is) or, on models, tuned (`finetune_params.
  model_params`). Cells show the sweep, a `×n` badge and the trial count. The
  variant total is read from generator sizes and marked `≈`; pass `variantCount`
  when the host has the authoritative number.
- **Bypass.** Canonical nirs4all has no enabled flag. A bypassed step, lane or
  group stays in the document as `{ "_bypassed_": <value> }` and
  `toCanonicalPipeline()` leaves it out. Persist the edited document, run the
  canonical one.
- **Keyboard.** One tab stop; arrows travel along the chain and across lanes,
  `Shift+Up/Down` selects the enclosing lane or group, `A` adds after the
  selection, `B` bypasses, `D` duplicates, `Alt+arrows` move the step, `Delete`
  removes, `Enter` opens the step's parameters. `Ctrl+Z` calls the host's
  `onUndo`. Cells also drag onto any insert point.

Hosts own loading, persistence, history, validation and execution. The editor
does not validate pipelines and does not know what an operator computes.

The tuning tests include a copied `ordered_search_space_v1.json` fixture from
full Python `nirs4all/tests/fixtures/tuning`. It verifies that this package
continues to parse and project the Python-generated
`nirs4all.tuning.ordered_search_space` contract; update the Python fixture first
when the contract intentionally changes.

Static assets are published through the existing `nirs4all-ui/assets/*` export:

```css
@import "nirs4all-ui/assets/styles/nirs4all-default.css";
@import "nirs4all-ui/assets/datasetBuilder.css";
@import "nirs4all-ui/assets/workbench.css";
@import "nirs4all-ui/assets/theme.css";
```

```ts
const css = getNirs4allStyleAsset("default-theme");
const builderCss = getNirs4allStyleAsset("dataset-builder");
const labTheme = getNirs4allStyleAsset("quality-lab-theme");
const animatedIcon = generateNirs4allBrandSvg("nirs4all-ui", {
  variant: "icon",
  animated: true,
});
```

## Optional browser entry for vanilla hosts

Pages without their own React tree (Formats and IO demonstrators, for example) can
mount a few existing components through `nirs4all-ui/browser`. It is a separate
build that bundles React 19, React DOM (client) and scheduler, so it never shares
React elements with a host's other React tree. Nothing in the pure view-model or SSR
entries imports it.

| File (`dist/browser/`) | Export | Use |
| --- | --- | --- |
| `nirs4all-ui-browser.iife.js` | `nirs4all-ui/browser/standalone` | Classic `<script>`; defines `globalThis.Nirs4allUIBrowser`. |
| `nirs4all-ui-browser.mjs` | `nirs4all-ui/browser` | ES module with the same three functions; no global assignment. Types: `index.d.ts`. |
| `browser.css` | `nirs4all-ui/browser/styles.css` | Class-scoped styles (no `:root` tokens or global element rules). |

```html
<link rel="stylesheet" href="vendor/ui/browser.css">
<script src="vendor/ui/nirs4all-ui-browser.iife.js"></script>
<script>
  const { mountDatasetPreview, mountSpectraExplorer, mountOwnerProposals } = Nirs4allUIBrowser;
  const card = mountDatasetPreview(document.getElementById("card"), { view: projectedView });
  const spectra = mountSpectraExplorer(document.getElementById("plot"), {
    title: "Raw spectra", axis, axisUnit: "nm", series, onSelect: (id) => hostSelect(id),
  });
  const proposals = mountOwnerProposals(document.getElementById("proposals"), {
    proposals: projected, busy: false,
    onConfirm: (id) => hostConfirm(id),
    onAlternative: (id, choiceId) => hostUseAlternative(id, choiceId),
    onOverride: (id, value) => hostOverride(id, value),
    onUndo: (kind, target) => hostUndo(kind, target),
  });
</script>
```

- Each `mount*` call creates one React root in a dedicated host child and renders
  synchronously. `update(nextProps)` replaces the complete props (no merging);
  `unmount()` releases the root and must run before the host clears or replaces that
  element (for example before `innerHTML = ""`).
- `mountDatasetPreview` accepts only `dataset`, `view` and `className`. Hosts that do not
  hold unique-sample counts pass a projected `view` with truthful labels (such as
  "Records" or "Rows") rather than a `dataset` input.
- `mountSpectraExplorer` takes the `SpectraExplorer` props (plain `values` arrays, `null`
  or `NaN` kept as gaps, unique display ids resolved by the host) and renders the
  explorer's own accessible band-data table (a native `<details>` with a band-index input;
  there is exactly one data table, and non-finite cells read "not available"). The locale
  defaults to English. Remount on axis, signal or series-group changes; use `update` for
  selection or title changes.
- `mountOwnerProposals` renders host-projected proposals in the given order, labels
  scores as uncalibrated and shows a dash for missing scores. Alternatives report
  their opaque `choiceId`; overrides report the exact host `choice.value`. The host
  keeps the original owner objects and runs every owner call.

Hosts stage `nirs4all-ui-browser.iife.js` (or the `.mjs`), `browser.css`,
`THIRD_PARTY_NOTICES.md` and the texts in `LICENSES/THIRD-PARTY/` together, because
the bundle contains MIT-licensed React code.

## Development

```bash
npm install
npm run typecheck
npm test
```

`npm run build` emits ESM JavaScript and declaration files under `dist/`, then
builds the optional browser entry into `dist/browser/` with `vite.browser.config.ts`.

## Immutable release artifact

Release CI builds one tarball and publishes that exact file instead of running
`npm publish` from a second source build. After the normal package gate, create
the tarball and its closed provenance manifest in an empty directory:

```bash
npm run ci
npm run release:artifact -- --output-dir release-artifact
npm run release:artifact:verify -- \
  --manifest release-artifact/nirs4all-ui-release-artifact.v1.json \
  --expected-commit "$(git rev-parse HEAD)"
```

The builder refuses tracked source modifications and records the exact Git
commit, package version, filename, byte size, SHA-256, npm SHA-1 and SHA-512
integrity. Studio and Web must consume the same verified tarball bytes; copying
the source tree or rebuilding separate local `file:` packages is not release
evidence.

## GitHub Pages showcase

The single-page component and helper catalogue lives under `site/`.

```bash
npm run site:dev
npm run site:build
```

`site/src/App.tsx` renders reusable React components separately from the
lab, dataset-builder, runtime, score, brand, style, and asset inventories. `site/public/`
intentionally carries the Pages publication files (`logo.svg`, `favicon.ico`,
`favicon.svg`, `robots.txt`, `sitemap.xml`, and `site.webmanifest`). The site
build also copies the package brand kit to namespaced GitHub Pages URLs under
`assets/brand/nirs4all-ui/` and publishes the reusable visual system under
`assets/brands/`, `assets/styles/`, and `assets/motion/`, while package-level
CSS such as `assets/datasetBuilder.css` and `assets/theme.css` remains
available through the npm asset export.
The npm package keeps the same files available through the
`nirs4all-ui/assets/*` export. Production Pages is currently served from the
GitHub project-page path with the default `/nirs4all-ui/` Vite base. When a
dedicated subdomain such as `ui.nirs4all.org` is enabled, switch the Pages
workflow to `NIRS4ALL_UI_BASE=/` and add `site/public/CNAME`.

`site/src/App.test.tsx` is the focused hardening check for the showcase: it
verifies that every public React component, lab, and dataset-builder export
appears in the page and that the mirrored brand/logo, crawler metadata,
manifest, default styles, package CSS assets, motion asset, reusable brand kit,
and canonical URLs stay in sync with the packaged asset set.

### Pipeline preset cards

`PipelinePresetCard` from `nirs4all-ui/components` presents Studio's preset metadata,
complexity, canonical recipe statistics and preview, with host-provided task actions
and icons. Import `nirs4all-ui/assets/pipeline-presets.css` for the shared appearance.
`nirs4all-ui/pipelines` exports the pure canonical preview, statistics and preset
model helpers. The component supports React server rendering for static catalogues;
it owns no routing, API access or application state.

The shared preset content is generated from Studio's `api/presets/*.yaml`:

```bash
python scripts/sync-studio-presets.py --studio ../nirs4all-studio
# Requires PyYAML; use a Studio or Repository Python environment.
```

`getStudioPipelinePresets()` returns independent copies of all ten defaults and
both task variants. Studio checks the snapshot against its authored YAML hashes;
Repository checks its recipes against the same shared data before rendering.
