# Browser server client

`@nirs4all/server-client` is a dependency-free native ESM transport for the nirs4all server. It does not parse `.n4a` archives or execute scientific operations. The host uses Core for container integrity and inventory, and owns persistence, consent and execution.

```js
import { ServerClient, ServerError } from '@nirs4all/server-client';

const client = new ServerClient('https://example.org/nirs4all', { token });
const principal = await client.principal(); // verified project and rights
const page = await client.listWorkspaces();
// After explicit user consent, upload a Core-produced Blob and save its reference:
const artifact = await client.upload(archive, { filename: 'workspace.n4a' });
const saved = await client.saveWorkspace('my-workspace', {
  name: 'My workspace', artifacts: [artifact.sha256], resources: [],
  metadata: { app: 'example', schema_version: 1 },
}, { expectedRevision: 0 });
client.disconnect();
```

Construction sends no request. Discovery and all other methods use the supplied project token as a Bearer credential, including through the deployed CORS gateway. Keep the client in memory, clear the input holding the token, and disconnect when done. Requests omit cookies, reject redirects, and require HTTPS except explicit localhost, 127.0.0.1 or [::1] HTTP endpoints. Base URLs may contain a path prefix but no credentials, query or fragment. Connection and data transfer must follow an explicit user action; a 409 on save is a conflict and must not silently overwrite local state.

`upload` passes the original Blob directly to fetch and checks the returned identifier and byte size against the receipt and Blob; it does not compute a local digest. `downloadArtifact` checks the server record's SHA identifier and byte size against the returned Blob; it does **not** recompute the digest or validate the archive. Hosts must use Core to verify container integrity before accepting its contents. Server errors provide a numeric `status` and a safe `code`; raw server bodies and network exceptions are not exposed. An upload cancelled after transmission may already have been stored.

The `@nirs4all/server-client/state` subpath provides the separate host-state codec. Hosts package its output with Core and validate their own versioned envelope on import.
