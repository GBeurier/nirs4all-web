/** Lossless host-state values. Core remains the owner of the enclosing n4a archive. */
const SCHEMA = 'nirs4all.browser-state.v1';
const MEMBER_PATH = /^workspace\/data\/(0|[1-9][0-9]*)\.bin$/;
const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });
const byteOrder = new Uint8Array(new Uint16Array([0x0102]).buffer)[0] === 2 ? 'LE' : 'BE';
// Some native implementations expose internal symbol slots as own properties.
const blobKeys = typeof Blob === 'function' ? new Set(Reflect.ownKeys(new Blob())) : new Set();
const fileKeys = typeof File === 'function' ? new Set(Reflect.ownKeys(new File([], ''))) : new Set();
const taggedNumbers = new Map([['NaN', NaN], ['Infinity', Infinity], ['-Infinity', -Infinity], ['-0', -0]]);
const typedPrototype = Object.getPrototypeOf(Uint8Array.prototype);
const typedBuffer = Object.getOwnPropertyDescriptor(typedPrototype, 'buffer').get;
const typedOffset = Object.getOwnPropertyDescriptor(typedPrototype, 'byteOffset').get;
const typedByteLength = Object.getOwnPropertyDescriptor(typedPrototype, 'byteLength').get;
const resizableBuffer = Object.getOwnPropertyDescriptor(ArrayBuffer.prototype, 'resizable')?.get;
const typedArrays = new Map();
for (const name of [
  'Int8Array', 'Uint8Array', 'Uint8ClampedArray', 'Int16Array', 'Uint16Array',
  'Int32Array', 'Uint32Array', 'Float16Array', 'Float32Array', 'Float64Array',
  'BigInt64Array', 'BigUint64Array',
]) {
  const constructor = globalThis[name];
  if (typeof constructor === 'function') typedArrays.set(name, constructor);
}

function unsupported(reason) {
  throw new TypeError(`Unsupported browser state value: ${reason}`);
}

function invalid(reason) {
  throw new TypeError(`Invalid browser state document: ${reason}`);
}

function isArrayBuffer(value) {
  return value instanceof ArrayBuffer && Object.getPrototypeOf(value) === ArrayBuffer.prototype;
}

function checkBinaryProperties(value, intrinsicKeys = new Set()) {
  for (const key of Reflect.ownKeys(value)) {
    if (intrinsicKeys.has(key)) {
      if (!Object.hasOwn(Object.getOwnPropertyDescriptor(value, key), 'value')) unsupported('accessor properties');
      continue;
    }
    unsupported('custom binary properties');
  }
}

function ownEntries(value, array = false) {
  const entries = [];
  for (const key of Reflect.ownKeys(value)) {
    if (array && key === 'length') continue;
    if (typeof key !== 'string') unsupported('symbol properties');
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!Object.hasOwn(descriptor, 'value')) unsupported('accessor properties');
    if (!descriptor.enumerable) unsupported('non-enumerable properties');
    entries.push([key, descriptor.value]);
  }
  return entries;
}

/**
 * Serialize host state into a UTF-8 document and generated binary members.
 * Object aliases are values. Views retain only their visible bytes; restored offsets are zero.
 * Enumerable data properties restore as ordinary writable/configurable properties.
 * Typed arrays are intrinsic byte values; extra JS properties are outside this wire value.
 * Cycles, custom classes and plain-object accessors are refused.
 */
export async function packState(value) {
  const members = [];
  const binaries = new WeakMap();
  const active = new WeakSet();

  async function binary(source, tag, metadata = [], visibleBytes) {
    if (binaries.has(source)) return binaries.get(source);
    const path = `workspace/data/${members.length}.bin`;
    const bytes = tag === 'buffer'
      ? (visibleBytes ?? new Uint8Array(source)).slice()
      : new Uint8Array(await source.arrayBuffer());
    const node = [tag, path, bytes.byteLength, ...metadata];
    members.push({ path, bytes });
    binaries.set(source, node);
    return node;
  }

  async function encode(current) {
    if (current === null || typeof current === 'string' || typeof current === 'boolean') return current;
    if (typeof current === 'number') {
      if (Number.isNaN(current)) return ['number', 'NaN'];
      if (current === Infinity) return ['number', 'Infinity'];
      if (current === -Infinity) return ['number', '-Infinity'];
      if (Object.is(current, -0)) return ['number', '-0'];
      return current;
    }
    if (typeof current === 'undefined') return ['undefined'];
    if (typeof current === 'bigint') return ['bigint', current.toString()];
    if (typeof current !== 'object') unsupported(typeof current);

    if (isArrayBuffer(current)) {
      checkBinaryProperties(current);
      if (resizableBuffer?.call(current)) unsupported('resizable ArrayBuffer');
      return binary(current, 'buffer');
    }
    if (ArrayBuffer.isView(current)) {
      const entry = [...typedArrays].find(([, constructor]) => Object.getPrototypeOf(current) === constructor.prototype);
      if (!entry) unsupported('unrecognized binary view');
      // Enumerating own keys would allocate one property name per numerical cell.
      // Intrinsic getters also avoid invoking user-defined shadow getters.
      const backing = typedBuffer.call(current);
      if (!isArrayBuffer(backing)) unsupported('non-ArrayBuffer backing storage');
      if (resizableBuffer?.call(backing)) unsupported('resizable ArrayBuffer');
      const bytes = new Uint8Array(backing, typedOffset.call(current), typedByteLength.call(current));
      return ['typed', entry[0], await binary(current, 'buffer', [], bytes)];
    }
    if (typeof File === 'function' && Object.getPrototypeOf(current) === File.prototype) {
      checkBinaryProperties(current, fileKeys);
      return binary(current, 'file', [current.type, current.name, await encode(current.lastModified)]);
    }
    if (typeof Blob === 'function' && Object.getPrototypeOf(current) === Blob.prototype) {
      checkBinaryProperties(current, blobKeys);
      return binary(current, 'blob', [current.type]);
    }
    const array = Array.isArray(current);
    const prototype = Object.getPrototypeOf(current);
    if (array ? prototype !== Array.prototype : prototype !== Object.prototype && prototype !== null) {
      unsupported('object prototype');
    }
    if (active.has(current)) unsupported('cyclic object');
    active.add(current);
    try {
      const entries = [];
      for (const [key, child] of ownEntries(current, array)) entries.push([key, await encode(child)]);
      return array ? ['array', current.length, entries] : ['object', prototype === null ? 'null' : 'plain', entries];
    } finally {
      active.delete(current);
    }
  }

  return { document: encoder.encode(JSON.stringify([SCHEMA, byteOrder, await encode(value)])), members };
}

/** Restore a host value from its document and Core-provided binary member reader. */
export async function unpackState(document, readMember) {
  if (!(document instanceof Uint8Array)) invalid('document must be Uint8Array');
  if (typeof readMember !== 'function') invalid('member reader must be a function');
  let envelope;
  try {
    envelope = JSON.parse(decoder.decode(document));
  } catch {
    invalid('invalid UTF-8 or JSON');
  }
  if (!Array.isArray(envelope) || envelope.length !== 3 || envelope[0] !== SCHEMA) invalid('unknown schema');
  if (envelope[1] !== 'LE' && envelope[1] !== 'BE') invalid('unknown source byte order');
  const identities = new Map();

  function integer(value) {
    return Number.isSafeInteger(value) && value >= 0 && !Object.is(value, -0);
  }

  function shape(node, length) {
    if (node.length !== length) invalid('invalid tag shape');
  }

  function number(node) {
    if (typeof node === 'number' && Number.isFinite(node) && !Object.is(node, -0)) return node;
    if (Array.isArray(node) && node.length === 2 && node[0] === 'number' && taggedNumbers.has(node[1])) {
      return taggedNumbers.get(node[1]);
    }
    invalid('invalid number');
  }

  async function binary(node) {
    const [tag, path, byteLength] = node;
    shape(node, tag === 'buffer' ? 3 : tag === 'blob' ? 4 : 6);
    if (typeof path !== 'string' || !MEMBER_PATH.test(path) || !integer(byteLength)) invalid('invalid member identity');
    if (tag !== 'buffer' && (typeof node[3] !== 'string' || !/^[\x20-\x7e]*$/.test(node[3])
      || node[3] !== node[3].toLowerCase())) invalid('invalid Blob type');
    let lastModified;
    if (tag === 'file') {
      if (typeof node[4] !== 'string') invalid('invalid File metadata');
      lastModified = number(node[5]);
    }
    const identity = JSON.stringify(node);
    const existing = identities.get(path);
    if (existing) {
      if (existing.identity !== identity) invalid('conflicting member references');
      return existing.value;
    }
    const value = (async () => {
      let bytes;
      try {
        bytes = await readMember(path);
      } catch {
        invalid('missing or unreadable member');
      }
      if (!(bytes instanceof Uint8Array)) invalid('missing or invalid member bytes');
      if (bytes.byteLength !== byteLength) invalid('member byte length mismatch');
      // Copy exactly the visible bytes, never unrelated bytes in a reader's backing buffer.
      const buffer = new Uint8Array(bytes).buffer;
      if (tag === 'buffer') return buffer;
      if (tag === 'blob') {
        if (typeof Blob !== 'function') invalid('Blob is unavailable');
        return new Blob([buffer], { type: node[3] });
      }
      if (typeof File !== 'function') invalid('File is unavailable');
      const file = new File([buffer], node[4], { type: node[3], lastModified });
      if (!Object.is(file.lastModified, lastModified)) invalid('incompatible File metadata');
      return file;
    })();
    identities.set(path, { identity, value });
    return value;
  }

  async function properties(entries, target, arrayLength) {
    if (!Array.isArray(entries)) invalid('invalid object entries');
    const keys = new Set();
    for (const pair of entries) {
      if (!Array.isArray(pair) || pair.length !== 2 || typeof pair[0] !== 'string') invalid('invalid object entry');
      const [key, child] = pair;
      if (keys.has(key)) invalid('duplicate object key');
      keys.add(key);
      if (arrayLength !== undefined) {
        if (key === 'length') invalid('invalid array property');
        const index = Number(key);
        if (Number.isInteger(index) && index >= 0 && index < 4294967295 && String(index) === key
          && index >= arrayLength) invalid('array index exceeds length');
      }
      Object.defineProperty(target, key, {
        value: await decode(child), enumerable: true, configurable: true, writable: true,
      });
    }
    return target;
  }

  async function decode(node) {
    if (node === null || typeof node === 'string' || typeof node === 'boolean') return node;
    if (typeof node === 'number') {
      if (!Number.isFinite(node) || Object.is(node, -0)) invalid('invalid untagged number');
      return node;
    }
    if (!Array.isArray(node) || typeof node[0] !== 'string') invalid('invalid value node');
    switch (node[0]) {
      case 'undefined':
        shape(node, 1);
        return undefined;
      case 'number': {
        shape(node, 2);
        if (!taggedNumbers.has(node[1])) invalid('unknown number tag');
        return number(node);
      }
      case 'bigint':
        shape(node, 2);
        if (typeof node[1] !== 'string' || !/^(0|-?[1-9][0-9]*)$/.test(node[1])) invalid('invalid BigInt');
        return BigInt(node[1]);
      case 'buffer':
      case 'blob':
      case 'file':
        return binary(node);
      case 'typed': {
        shape(node, 3);
        const constructor = typedArrays.get(node[1]);
        if (!constructor || !Array.isArray(node[2]) || node[2][0] !== 'buffer') invalid('invalid typed array');
        const width = constructor.BYTES_PER_ELEMENT;
        if (width > 1 && envelope[1] !== byteOrder) invalid('incompatible source byte order');
        const buffer = await binary(node[2]);
        if (buffer.byteLength % width !== 0) invalid('typed array byte length mismatch');
        return new constructor(buffer);
      }
      case 'array':
        shape(node, 3);
        if (!integer(node[1]) || node[1] > 4294967295) invalid('invalid JavaScript array length');
        return properties(node[2], new Array(node[1]), node[1]);
      case 'object':
        shape(node, 3);
        if (node[1] !== 'plain' && node[1] !== 'null') invalid('unknown object prototype');
        return properties(node[2], node[1] === 'null' ? Object.create(null) : {});
      default:
        invalid('unknown value tag');
    }
  }

  return decode(envelope[2]);
}
