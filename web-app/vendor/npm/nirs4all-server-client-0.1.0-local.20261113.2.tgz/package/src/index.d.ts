export class ServerError extends Error {
  readonly code: string;
  readonly status: number;
  constructor(code: string, status?: number);
}

export type JsonValue = null | boolean | number | string | JsonValue[] | { [key: string]: JsonValue };
export type JsonObject = { [key: string]: JsonValue };
export interface Principal {
  project_id: string;
  principal_id: string;
  services: string[];
  rights: string[];
}
export interface WorkspaceSnapshot {
  name: string;
  artifacts: string[];
  resources: JsonValue[];
  metadata: JsonObject;
}
export interface WorkspaceRecord {
  workspace_id: string;
  revision: number;
  snapshot: WorkspaceSnapshot;
  [key: string]: unknown;
}
export interface WorkspacePage {
  items: WorkspaceRecord[];
  next_cursor: string | null;
}
export interface ArtifactRecord {
  artifact_id: string;
  sha256: string;
  size_bytes: number;
  filename: string;
  [key: string]: unknown;
}
export interface ClientOptions {
  token: string;
  fetch?: typeof globalThis.fetch;
  timeoutMs?: number;
}
export class ServerClient {
  constructor(baseUrl: string, options: ClientOptions);
  principal(): Promise<Principal>;
  discover(): Promise<JsonObject>;
  listWorkspaces(options?: { limit?: number; cursor?: string }): Promise<WorkspacePage>;
  getWorkspace(id: string, options?: { revision?: number }): Promise<WorkspaceRecord>;
  saveWorkspace(id: string, snapshot: WorkspaceSnapshot, options: { expectedRevision: number }): Promise<WorkspaceRecord>;
  upload(blob: Blob, options?: { filename?: string; signal?: AbortSignal }): Promise<ArtifactRecord>;
  getArtifact(sha: string): Promise<ArtifactRecord>;
  downloadArtifact(sha: string, options?: { signal?: AbortSignal }): Promise<Blob>;
  previewActions(sha: string): Promise<JsonObject>;
  processActions(sha: string, actions: JsonObject[]): Promise<JsonObject>;
  disconnect(): void;
}
