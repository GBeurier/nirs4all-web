/** A generated binary member to pass to the host's Core n4a writer. */
export interface StateMember {
  path: string;
  bytes: Uint8Array;
}

export interface PackedState {
  document: Uint8Array;
  members: StateMember[];
}

/**
 * Serialize plain host values, arrays, native typed arrays, ArrayBuffer, Blob/File,
 * BigInt, undefined, and all JavaScript numbers. Refuses cycles and unsupported
 * objects/properties. Object aliases are copied by value. Typed-array views keep
 * only their visible bytes and restore at byte offset zero, without sharing the
 * original backing buffer. Direct ArrayBuffers retain all their bytes.
 * Typed-array values include their intrinsic type/bytes only; extra JavaScript
 * properties are outside that binary wire value and are not inspected or copied.
 * Frozen/plain enumerable data fields restore as ordinary writable properties;
 * non-enumerable custom fields and accessors refuse.
 * This does not create or validate an n4a container/host profile.
 */
export function packState(value: unknown): Promise<PackedState>;

/**
 * Restore host values, rejecting unknown schemas/tags, malformed or conflicting
 * references and missing members. File values require native File support.
 * Multi-byte typed arrays refuse a different source/native byte order.
 * Hosts must validate their own profile/envelope before applying restored state.
 */
export function unpackState(
  document: Uint8Array,
  readMember: (path: string) => Promise<Uint8Array>,
): Promise<unknown>;
