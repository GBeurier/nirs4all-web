/** Safe transport failure. No underlying exception or response body is exposed. */
export class ServerError extends Error {
  constructor(code, status = 0) {
    super(code);
    this.name = 'ServerError';
    this.code = code;
    this.status = status;
  }
}

const invalid = () => { throw new ServerError('invalid_argument'); };
const shaPattern = /^[0-9a-f]{64}$/;
const workspacePattern = /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/;

function baseAddress(value) {
  if (typeof value !== 'string' || !/^https?:\/\/[^/?#]+(?:\/[A-Za-z0-9_~.-]+)*\/?$/i.test(value)) {
    throw new ServerError('invalid_base_url');
  }
  let url;
  try { url = new URL(value); } catch { throw new ServerError('invalid_base_url'); }
  const rawPath = value.match(/^https?:\/\/[^/?#]+(.*)$/i)[1];
  if (value.match(/^https?:\/\/([^/?#]+)/i)[1].includes('@') || url.username || url.password ||
      url.port === '0' || rawPath.split('/').some((part) => part === '.' || part === '..') ||
      url.pathname !== (rawPath || '/')) throw new ServerError('invalid_base_url');
  if (url.protocol !== 'https:' && !(url.protocol === 'http:' &&
      /^(?:localhost|127\.0\.0\.1|\[::1\])(?::[0-9]+)?$/i.test(value.match(/^https?:\/\/([^/?#]+)/i)[1]))) {
    throw new ServerError('https_required');
  }
  return url.origin + url.pathname.replace(/\/$/, '');
}

function workspaceId(id) {
  if (typeof id !== 'string' || !workspacePattern.test(id)) invalid();
  return id;
}
function artifactId(id) {
  if (typeof id !== 'string' || !shaPattern.test(id)) invalid();
  return id;
}
function integer(value, minimum) {
  if (!Number.isSafeInteger(value) || value < minimum) invalid();
  return value;
}
function query(params) {
  const query = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) if (value !== undefined) query.set(key, String(value));
  const result = query.toString();
  return result ? `?${result}` : '';
}

/** Browser-only transport. Construction never contacts the server. */
export class ServerClient {
  #base;
  #token;
  #fetch;
  #timeout;
  #pending = new Set();

  constructor(baseUrl, { token, fetch: fetchImpl = globalThis.fetch, timeoutMs = 30000 } = {}) {
    this.#base = baseAddress(baseUrl);
    if (typeof token !== 'string' || !/^[\x21-\x7e]{1,1024}$/.test(token) ||
        typeof fetchImpl !== 'function' || !Number.isSafeInteger(timeoutMs) || timeoutMs <= 0) invalid();
    this.#token = token;
    this.#fetch = fetchImpl;
    this.#timeout = timeoutMs;
  }

  async #request(path, { method = 'GET', body, headers = {}, signal, blob = false } = {}) {
    if (!this.#token) throw new ServerError('disconnected');
    const controller = new AbortController();
    this.#pending.add(controller);
    const abort = () => controller.abort();
    if (signal) {
      if (signal.aborted) controller.abort();
      else signal.addEventListener('abort', abort, { once: true });
    }
    const timer = setTimeout(abort, this.#timeout);
    try {
      const requestHeaders = { ...headers };
      requestHeaders.Authorization = `Bearer ${this.#token}`;
      const response = await this.#fetch.call(globalThis, this.#base + path, {
        method, headers: requestHeaders, body, signal: controller.signal,
        credentials: 'omit', redirect: 'error', cache: 'no-store', referrerPolicy: 'no-referrer',
      });
      if (!response.ok) {
        let code = `http_${response.status}`;
        try {
          const candidate = (await response.json())?.error?.code;
          if (typeof candidate === 'string' && /^[a-z0-9][a-z0-9_.-]{0,63}$/.test(candidate) &&
              !candidate.includes(this.#token)) code = candidate;
        } catch { /* response bodies are not surfaced */ }
        throw new ServerError(code, response.status);
      }
      if (blob) return await response.blob();
      const result = await response.json();
      if (!result || typeof result !== 'object' || Array.isArray(result)) throw new ServerError('invalid_response');
      return result;
    } catch (error) {
      if (error instanceof ServerError) throw error;
      throw new ServerError(controller.signal.aborted ? 'request_cancelled' : 'request_failed');
    } finally {
      clearTimeout(timer);
      if (signal) signal.removeEventListener('abort', abort);
      this.#pending.delete(controller);
    }
  }

  async principal() {
    const principal = await this.#request('/api/v1/principal');
    if (typeof principal.project_id !== 'string' || typeof principal.principal_id !== 'string' ||
        !Array.isArray(principal.services) || !principal.services.every((item) => typeof item === 'string') ||
        !Array.isArray(principal.rights) || !principal.rights.every((item) => typeof item === 'string')) {
      throw new ServerError('invalid_response');
    }
    return principal;
  }
  discover() { return this.#request('/.well-known/nirs4all'); }
  listWorkspaces({ limit, cursor } = {}) {
    if (limit !== undefined) integer(limit, 1);
    if (cursor !== undefined && typeof cursor !== 'string') invalid();
    return this.#request('/api/v1/workspaces' + query({ limit, cursor }));
  }
  getWorkspace(id, { revision } = {}) {
    if (revision !== undefined) integer(revision, 1);
    return this.#request(`/api/v1/workspaces/${workspaceId(id)}` + query({ revision }));
  }
  saveWorkspace(id, snapshot, { expectedRevision } = {}) {
    integer(expectedRevision, 0);
    if (!snapshot || typeof snapshot !== 'object' || Array.isArray(snapshot)) invalid();
    let body;
    try { body = JSON.stringify({ snapshot, expected_revision: expectedRevision }); } catch { invalid(); }
    return this.#request(`/api/v1/workspaces/${workspaceId(id)}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' }, body,
    });
  }
  async upload(blob, { filename, signal } = {}) {
    if (!(blob instanceof Blob)) invalid();
    const headers = { 'Content-Type': 'application/vnd.nirs4all.n4a' };
    if (filename !== undefined) {
      if (typeof filename !== 'string' || !/^[\x20-\x7e]{1,255}$/.test(filename) ||
          /[/\\]/.test(filename) || filename === '.' || filename === '..') invalid();
      headers['X-Filename'] = filename;
    }
    const record = await this.#request('/api/v1/artifacts', { method: 'POST', headers, body: blob, signal });
    if (typeof record.sha256 !== 'string' || !shaPattern.test(record.sha256) ||
        record.artifact_id !== record.sha256 || record.size_bytes !== blob.size) {
      throw new ServerError('invalid_response');
    }
    return record;
  }
  getArtifact(sha) { return this.#request(`/api/v1/artifacts/${artifactId(sha)}`); }
  async downloadArtifact(sha, { signal } = {}) {
    artifactId(sha);
    const record = await this.#request(`/api/v1/artifacts/${sha}`, { signal });
    if (record.sha256 !== sha || !Number.isSafeInteger(record.size_bytes) || record.size_bytes < 0) {
      throw new ServerError('invalid_response');
    }
    const data = await this.#request(`/api/v1/artifacts/${sha}/download`, { signal, blob: true });
    if (data.size !== record.size_bytes) throw new ServerError('download_size_mismatch');
    return data;
  }
  previewActions(sha) { return this.#request(`/api/v1/artifacts/${artifactId(sha)}/actions`); }
  processActions(sha, actions) {
    if (!Array.isArray(actions) || !actions.length) invalid();
    let body;
    try { body = JSON.stringify({ actions }); } catch { invalid(); }
    return this.#request(`/api/v1/artifacts/${artifactId(sha)}/actions`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body,
    });
  }
  disconnect() {
    this.#token = null;
    for (const controller of this.#pending) controller.abort();
    this.#pending.clear();
  }
}
